# Graded Quiz: Portfolio Optimization using Markowitz Model

## Instructions

This quiz tests your understanding of the key concepts covered in the Portfolio Optimization using Markowitz Model course. You have 90 minutes to complete the quiz. 

**Important Notes:**
- This quiz is worth 20% of your final grade
- You need a score of 70% or higher to pass
- You may use a calculator and formula sheet
- Show your work for calculation problems to receive partial credit
- Choose the best answer for multiple-choice questions

---

## Section A: Multiple Choice Questions (5 points each)

### Question 1
Which of the following best describes the main contribution of Harry Markowitz's portfolio theory?

A) He showed that investors should put all their money in the highest returning asset  
B) He developed the first method to predict future stock prices accurately  
C) He demonstrated how to mathematically balance risk and return through diversification  
D) He proved that diversification always reduces portfolio risk to zero  

**Correct Answer: C**  
*Explanation: Markowitz showed how to quantify the risk-return trade-off and optimize portfolios through mathematical diversification, not by eliminating risk entirely.*

### Question 2  
The correlation coefficient between two assets can range from:

A) 0 to +1  
B) -1 to +1  
C) -∞ to +∞  
D) 0 to +∞  

**Correct Answer: B**  
*Explanation: Correlation coefficients always range from -1 (perfect negative correlation) to +1 (perfect positive correlation).*

### Question 3
If two assets have a correlation of -0.8, this means:

A) They move in the same direction most of the time  
B) They have no relationship to each other  
C) They tend to move in opposite directions  
D) One asset is 80% riskier than the other  

**Correct Answer: C**  
*Explanation: A negative correlation indicates assets tend to move in opposite directions, providing diversification benefits.*

### Question 4
The Sharpe ratio measures:

A) The total return of a portfolio  
B) The risk-adjusted return per unit of total risk  
C) The correlation between portfolio returns and market returns  
D) The maximum loss a portfolio can experience  

**Correct Answer: B**  
*Explanation: The Sharpe ratio = (Portfolio Return - Risk-free Rate) / Portfolio Standard Deviation, measuring excess return per unit of total risk.*

### Question 5
In the two-asset Markowitz portfolio variance formula σ²ₚ = w₁²σ₁² + w₂²σ₂² + 2w₁w₂σ₁σ₂ρ₁₂, what happens to portfolio risk when the correlation (ρ₁₂) decreases?

A) Portfolio risk increases  
B) Portfolio risk decreases  
C) Portfolio risk stays the same  
D) The effect depends on the asset weights  

**Correct Answer: B**  
*Explanation: Lower correlation reduces the positive contribution of the covariance term (2w₁w₂σ₁σ₂ρ₁₂), thereby reducing total portfolio variance.*

### Question 6
The efficient frontier represents:

A) All possible portfolios an investor can create  
B) Only portfolios with the highest possible returns  
C) Portfolios offering maximum return for each level of risk  
D) Portfolios with zero correlation between assets  

**Correct Answer: C**  
*Explanation: The efficient frontier shows the set of optimal portfolios offering the highest expected return for each level of risk.*

### Question 7
A Sharpe ratio of 1.5 would be considered:

A) Poor performance  
B) Below average performance  
C) Good performance  
D) Impossible to achieve  

**Correct Answer: C**  
*Explanation: Sharpe ratios above 1.0 are considered good, with 1.5 being well above the threshold for good risk-adjusted performance.*

### Question 8
The main assumption that limits the practical application of the Markowitz model is:

A) Investors are risk-averse  
B) Future returns, volatilities, and correlations are known with certainty  
C) Markets are liquid  
D) Transaction costs exist  

**Correct Answer: B**  
*Explanation: The model requires precise estimates of future parameters, which are actually unknown and must be estimated from historical data.*

---

## Section B: Calculation Problems (10 points each)

### Question 9
Given the following information for two assets:
- Asset A: Expected return = 12%, Standard deviation = 20%
- Asset B: Expected return = 8%, Standard deviation = 15%
- Correlation between A and B = 0.3
- Risk-free rate = 3%

Calculate the expected return, variance, and Sharpe ratio for a portfolio with 60% invested in Asset A and 40% invested in Asset B.

**Solution:**

**Portfolio Expected Return:**
E(Rₚ) = wₐE(Rₐ) + wᵦE(Rᵦ)  
E(Rₚ) = 0.6(0.12) + 0.4(0.08) = 0.072 + 0.032 = 0.104 = 10.4%

**Portfolio Variance:**
σ²ₚ = w²ₐσ²ₐ + w²ᵦσ²ᵦ + 2wₐwᵦσₐσᵦρₐᵦ  
σ²ₚ = (0.6)²(0.20)² + (0.4)²(0.15)² + 2(0.6)(0.4)(0.20)(0.15)(0.3)  
σ²ₚ = 0.36(0.04) + 0.16(0.0225) + 2(0.6)(0.4)(0.20)(0.15)(0.3)  
σ²ₚ = 0.0144 + 0.0036 + 0.00216 = 0.02016  

**Portfolio Standard Deviation:**
σₚ = √0.02016 = 0.142 = 14.2%

**Sharpe Ratio:**
SR = (E(Rₚ) - Rf)/σₚ = (0.104 - 0.03)/0.142 = 0.074/0.142 = 0.52

**Answer: Expected Return = 10.4%, Variance = 0.02016, Sharpe Ratio = 0.52**

### Question 10
Using the same asset information from Question 9, what portfolio weights would you expect for the minimum variance portfolio? (No calculation required - conceptual answer)

**Solution:**
For a minimum variance portfolio with two assets, we use the formula:

wₐ = (σ²ᵦ - σₐσᵦρₐᵦ)/(σ²ₐ + σ²ᵦ - 2σₐσᵦρₐᵦ)

Substituting values:
wₐ = (0.15² - 0.20×0.15×0.3)/(0.20² + 0.15² - 2×0.20×0.15×0.3)  
wₐ = (0.0225 - 0.009)/(0.04 + 0.0225 - 0.018) = 0.0135/0.0445 = 0.303

Therefore: wₐ = 30.3%, wᵦ = 69.7%

**Answer: Approximately 30% Asset A, 70% Asset B**

---

## Section C: Short Answer Questions (5 points each)

### Question 11
Explain the concept of diversification benefit in your own words and describe when it is maximized.

**Sample Answer:**
Diversification benefit occurs when combining assets in a portfolio results in lower overall risk than the weighted average of individual asset risks. This happens because assets don't move perfectly together - when one asset performs poorly, another may perform well, offsetting some losses. 

Diversification benefit is maximized when:
- Assets have low or negative correlation
- Assets have similar individual risk levels
- Portfolio weights are relatively balanced (not concentrated in one asset)

The mathematical basis is that portfolio variance includes a covariance term (2w₁w₂σ₁σ₂ρ₁₂) which becomes more negative (beneficial) as correlation decreases.

### Question 12
List three key limitations of the Markowitz model that investors should consider when applying it in practice.

**Sample Answer:**
1. **Parameter Estimation**: The model requires precise estimates of future returns, volatilities, and correlations, but these must be estimated from historical data which may not represent future conditions.

2. **Single Period Assumption**: The model assumes a single investment period, but real investors have multi-period horizons with ongoing cash flows and changing circumstances.

3. **Transaction Costs and Constraints**: The model ignores transaction costs, taxes, and practical constraints like minimum investment amounts or inability to short sell, which can make theoretically optimal portfolios impractical to implement.

### Question 13
What is the efficient frontier and why is it important for portfolio management?

**Sample Answer:**
The efficient frontier is the set of all portfolios that offer the maximum expected return for each level of risk (or minimum risk for each level of return). It represents the "best" possible portfolios available to investors.

Importance for portfolio management:
- **Benchmark for Evaluation**: Allows comparison of actual portfolios against theoretical optimums
- **Risk-Return Visualization**: Helps investors understand trade-offs between risk and return
- **Asset Allocation Guidance**: Provides framework for strategic portfolio construction
- **Performance Attribution**: Helps identify whether poor performance is due to security selection or poor asset allocation

---

## Section D: Essay Question (15 points)

### Question 14
Compare and contrast the Markowitz model approach to portfolio construction with a simple equal-weighting strategy. Discuss the theoretical advantages of each approach, practical implementation considerations, and circumstances where one might be preferred over the other.

**Grading Rubric:**
- **Theoretical Understanding (5 points)**: Clearly explains both approaches and their theoretical foundations
- **Practical Considerations (5 points)**: Discusses implementation challenges, costs, and real-world factors
- **Critical Analysis (3 points)**: Weighs pros and cons of each approach thoughtfully
- **Writing Quality (2 points)**: Clear, organized, and well-written response

**Sample Answer Outline:**

**Markowitz Model Approach:**
*Advantages:*
- Mathematically optimal risk-return trade-off
- Considers correlations between assets for diversification
- Provides theoretical framework for understanding portfolio risk
- Can be customized for different risk tolerances

*Disadvantages:*
- Requires extensive data and parameter estimation
- Sensitive to input assumptions (garbage in, garbage out)
- Complex to implement and understand
- May suggest extreme allocations that are impractical

**Equal-Weighting Strategy:**
*Advantages:*
- Simple to understand and implement
- No need for complex parameter estimation
- Naturally diversified across selected assets
- Less prone to estimation errors
- Lower transaction costs due to simpler rebalancing

*Disadvantages:*
- Ignores differences in expected returns and risks
- May not be optimal for investor's specific risk tolerance
- No consideration of correlation benefits
- Treats all assets as equally attractive

**When to Use Each:**
- **Markowitz**: When you have high confidence in parameter estimates, sophisticated analytical capabilities, and willingness to bear complexity for potential optimization gains
- **Equal-Weighting**: When simplicity is valued, parameter estimates are unreliable, or when dealing with assets of similar expected risk-return profiles

**Conclusion:** Both approaches have merit, and many practitioners use hybrid approaches that incorporate Markowitz insights while maintaining simplicity where appropriate.

---

## Answer Key Summary

**Section A (Multiple Choice):**
1. C  2. B  3. C  4. B  5. B  6. C  7. C  8. B

**Section B (Calculations):**
9. Return = 10.4%, Variance = 0.02016, Sharpe = 0.52  
10. 30% Asset A, 70% Asset B

**Section C (Short Answer):**
11-13: See detailed sample answers above

**Section D (Essay):**
14: See rubric and sample outline above

---

## Scoring:
- **Total Points Possible**: 100
- **Passing Score**: 70 points
- **Grade Scale**: 
  - A: 90-100 points
  - B: 80-89 points  
  - C: 70-79 points
  - F: Below 70 points

**Time Limit**: 90 minutes  
**Good luck!**