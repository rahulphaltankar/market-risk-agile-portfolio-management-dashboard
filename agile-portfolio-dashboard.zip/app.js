// Agile Portfolio Management Dashboard JavaScript

class AgilePortfolioDashboard {
    constructor() {
        this.currentSection = 'dashboard';
        this.charts = {};
        this.data = {
            epics: [
                {id: "MR-001", title: "Real-time VaR Calculation Platform", businessValue: 95, effort: 8, priority: "High", status: "In Progress", owner: "Sarah Chen", valueStream: "Market Risk Technology", roi: 2.5, regulatory: "Basel III", quarter: "Q4 2025"},
                {id: "MR-002", title: "Stress Testing Automation Framework", businessValue: 85, effort: 13, priority: "High", status: "Planning", owner: "Michael Rodriguez", valueStream: "Risk Analytics", roi: 1.8, regulatory: "CCAR", quarter: "Q1 2026"},
                {id: "MR-003", title: "Counterparty Risk Dashboard", businessValue: 75, effort: 5, priority: "Medium", status: "Backlog", owner: "Jennifer Liu", valueStream: "Counterparty Risk", roi: 1.4, regulatory: "SA-CCR", quarter: "Q2 2026"},
                {id: "MR-004", title: "Market Data Quality Enhancement", businessValue: 70, effort: 8, priority: "Medium", status: "In Progress", owner: "David Thompson", valueStream: "Market Risk Technology", roi: 1.6, regulatory: "FRTB", quarter: "Q4 2025"},
                {id: "MR-005", title: "ESG Risk Integration", businessValue: 80, effort: 13, priority: "High", status: "Planning", owner: "Emma Williams", valueStream: "Risk Analytics", roi: 2.2, regulatory: "ECB Climate Stress Test", quarter: "Q1 2026"}
            ],
            arts: [
                {name: "Market Risk Core", rte: "James Anderson", teams: 6, members: 48, velocity: 156, capacity: 180, utilization: 87, valueStream: "Market Risk Technology"},
                {name: "Risk Analytics Engine", rte: "Maria Santos", teams: 4, members: 32, velocity: 98, capacity: 120, utilization: 82, valueStream: "Risk Analytics"},
                {name: "Counterparty Solutions", rte: "Robert Kim", teams: 3, members: 24, velocity: 72, capacity: 90, utilization: 80, valueStream: "Counterparty Risk"}
            ],
            kpis: {
                onTrack: 60,
                atRisk: 30,
                blocked: 10,
                resourceUtilization: 85,
                deliveryPredictability: 82,
                qualityScore: 4.1,
                budgetUtilization: 78
            }
        };
        
        this.initializeApp();
    }

    initializeApp() {
        // Use setTimeout to ensure DOM is fully loaded
        setTimeout(() => {
            this.setupEventListeners();
            this.setupNavigation();
            this.initializeCharts();
            this.setupDragAndDrop();
            this.updateDashboard();
            console.log('Dashboard initialized successfully');
        }, 100);
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');
        
        // Navigation tabs - using event delegation
        const navContainer = document.querySelector('.nav-tabs');
        if (navContainer) {
            navContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-tab')) {
                    const section = e.target.getAttribute('data-section');
                    console.log('Navigation clicked:', section);
                    this.navigateToSection(section);
                }
            });
        }

        // Export button
        const exportBtn = document.getElementById('export-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('Export button clicked');
                this.exportReport();
            });
        }

        // Filter selects - using event delegation
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('filter-select')) {
                console.log('Filter changed');
                this.applyFilters();
            }
        });

        // Report generation buttons - using event delegation
        document.addEventListener('click', (e) => {
            if (e.target.closest('.report-card') && e.target.classList.contains('btn')) {
                console.log('Report button clicked');
                this.generateReport(e.target);
            }
        });

        console.log('Event listeners set up complete');
    }

    setupNavigation() {
        console.log('Setting up navigation...');
        // Ensure dashboard is shown initially
        this.navigateToSection('dashboard');
    }

    navigateToSection(sectionId) {
        console.log(`Navigating to section: ${sectionId}`);
        
        // Hide all sections
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => {
            section.classList.remove('active');
            section.style.display = 'none';
        });

        // Remove active class from all tabs
        const tabs = document.querySelectorAll('.nav-tab');
        tabs.forEach(tab => {
            tab.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            targetSection.style.display = 'block';
            console.log(`Section ${sectionId} displayed`);
        } else {
            console.error(`Section ${sectionId} not found`);
        }

        // Activate corresponding tab
        const activeTab = document.querySelector(`[data-section="${sectionId}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
            console.log(`Tab ${sectionId} activated`);
        } else {
            console.error(`Tab for ${sectionId} not found`);
        }

        this.currentSection = sectionId;

        // Update charts if necessary
        if (sectionId === 'dashboard' || sectionId === 'art') {
            setTimeout(() => {
                this.updateCharts();
            }, 200);
        }
    }

    initializeCharts() {
        console.log('Initializing charts...');
        setTimeout(() => {
            this.createVelocityChart();
            this.createCapacityChart();
        }, 500);
    }

    createVelocityChart() {
        const ctx = document.getElementById('velocity-chart');
        if (!ctx) {
            console.log('Velocity chart canvas not found');
            return;
        }

        console.log('Creating velocity chart...');

        const velocityData = {
            labels: ['PI 2025.1', 'PI 2025.2', 'PI 2025.3', 'PI 2025.4'],
            datasets: [
                {
                    label: 'Market Risk Core',
                    data: [142, 148, 152, 156],
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.3
                },
                {
                    label: 'Risk Analytics Engine',
                    data: [88, 92, 95, 98],
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.3
                },
                {
                    label: 'Counterparty Solutions',
                    data: [65, 68, 70, 72],
                    borderColor: '#B4413C',
                    backgroundColor: 'rgba(180, 65, 60, 0.1)',
                    tension: 0.3
                }
            ]
        };

        this.charts.velocity = new Chart(ctx, {
            type: 'line',
            data: velocityData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'ART Velocity Trends (Story Points)',
                        font: { size: 14, weight: 'bold' }
                    },
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Story Points'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Program Increment'
                        }
                    }
                }
            }
        });

        console.log('Velocity chart created successfully');
    }

    createCapacityChart() {
        const ctx = document.getElementById('capacity-chart');
        if (!ctx) {
            console.log('Capacity chart canvas not found');
            return;
        }

        console.log('Creating capacity chart...');

        const capacityData = {
            labels: this.data.arts.map(art => art.name),
            datasets: [
                {
                    label: 'Current Velocity',
                    data: this.data.arts.map(art => art.velocity),
                    backgroundColor: '#1FB8CD'
                },
                {
                    label: 'Total Capacity',
                    data: this.data.arts.map(art => art.capacity),
                    backgroundColor: '#ECEBD5'
                }
            ]
        };

        this.charts.capacity = new Chart(ctx, {
            type: 'bar',
            data: capacityData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'ART Capacity vs Velocity',
                        font: { size: 14, weight: 'bold' }
                    },
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Story Points'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Agile Release Trains'
                        }
                    }
                }
            }
        });

        console.log('Capacity chart created successfully');
    }

    updateCharts() {
        console.log('Updating charts...');
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.update === 'function') {
                chart.update();
            }
        });
    }

    setupDragAndDrop() {
        console.log('Setting up drag and drop...');
        
        // Use setTimeout to ensure elements are available
        setTimeout(() => {
            const epicCards = document.querySelectorAll('.epic-card');
            const columns = document.querySelectorAll('.epic-cards');

            console.log(`Found ${epicCards.length} epic cards and ${columns.length} columns`);

            epicCards.forEach(card => {
                card.draggable = true;
                card.addEventListener('dragstart', this.handleDragStart.bind(this));
                card.addEventListener('dragend', this.handleDragEnd.bind(this));
            });

            columns.forEach(column => {
                column.addEventListener('dragover', this.handleDragOver.bind(this));
                column.addEventListener('drop', this.handleDrop.bind(this));
            });
        }, 1000);
    }

    handleDragStart(e) {
        console.log('Drag started:', e.target.getAttribute('data-epic'));
        e.dataTransfer.setData('text/plain', e.target.getAttribute('data-epic'));
        e.target.style.opacity = '0.5';
    }

    handleDragEnd(e) {
        console.log('Drag ended');
        e.target.style.opacity = '1';
    }

    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.style.backgroundColor = 'rgba(31, 184, 205, 0.1)';
    }

    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.style.backgroundColor = '';
        
        const epicId = e.dataTransfer.getData('text/plain');
        const newStatus = e.currentTarget.getAttribute('data-status');
        const epicCard = document.querySelector(`[data-epic="${epicId}"]`);
        
        console.log(`Dropping ${epicId} into ${newStatus}`);
        
        if (epicCard && newStatus) {
            // Move the card to the new column
            e.currentTarget.appendChild(epicCard);
            
            // Update the epic status in data
            const epic = this.data.epics.find(e => e.id === epicId);
            if (epic) {
                epic.status = this.getStatusFromColumn(newStatus);
            }
            
            // Update column counts
            this.updateColumnCounts();
            
            // Show success message
            this.showNotification(`Epic ${epicId} moved to ${newStatus}`, 'success');
        }
    }

    getStatusFromColumn(columnStatus) {
        const statusMap = {
            'backlog': 'Backlog',
            'planning': 'Planning',
            'in-progress': 'In Progress',
            'done': 'Done'
        };
        return statusMap[columnStatus] || columnStatus;
    }

    updateColumnCounts() {
        document.querySelectorAll('.board-column').forEach(column => {
            const count = column.querySelectorAll('.epic-card').length;
            const countElement = column.querySelector('.count');
            if (countElement) {
                countElement.textContent = count;
            }
        });
    }

    applyFilters() {
        const filterSelects = document.querySelectorAll('.filter-select');
        let activeFilter = 'all';
        
        filterSelects.forEach(select => {
            if (select.value !== 'all') {
                activeFilter = select.value;
            }
        });
        
        console.log('Applying filter:', activeFilter);
        
        if (activeFilter !== 'all') {
            this.showNotification(`Filtered by: ${activeFilter.replace('-', ' ')}`, 'info');
        } else {
            this.showNotification('Filter cleared - showing all items', 'info');
        }
    }

    updateDashboard() {
        console.log('Updating dashboard...');
        // Update KPI cards with real-time data simulation
        this.simulateRealTimeUpdates();
        
        // Update counts and metrics
        this.updateMetrics();
    }

    simulateRealTimeUpdates() {
        // Simulate small changes in KPIs over time
        setInterval(() => {
            const utilizationCard = document.querySelector('.kpi-card.info .kpi-value');
            if (utilizationCard) {
                const currentValue = parseInt(utilizationCard.textContent);
                const variation = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
                const newValue = Math.max(80, Math.min(90, currentValue + variation));
                utilizationCard.textContent = `${newValue}%`;
            }
        }, 30000); // Update every 30 seconds
    }

    updateMetrics() {
        // Update progress bars based on current data
        setTimeout(() => {
            const progressBars = document.querySelectorAll('.progress-bar');
            progressBars.forEach((bar, index) => {
                const values = [82, 82, 78]; // Delivery, Quality, Budget
                if (values[index]) {
                    bar.style.width = `${values[index]}%`;
                }
            });

            // Update utilization bars in ART section
            const utilizationBars = document.querySelectorAll('.utilization-fill');
            utilizationBars.forEach((bar, index) => {
                if (this.data.arts[index]) {
                    bar.style.width = `${this.data.arts[index].utilization}%`;
                }
            });
        }, 100);
    }

    exportReport() {
        console.log('Exporting report...');
        // Show immediate feedback
        this.showNotification('Generating portfolio report...', 'info');
        
        setTimeout(() => {
            // Create a simple text report
            const reportData = this.generateReportData();
            const blob = new Blob([reportData], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `portfolio-report-${new Date().toISOString().split('T')[0]}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Portfolio report exported successfully!', 'success');
        }, 1500);
    }

    generateReportData() {
        const date = new Date().toLocaleDateString();
        return `MARKET RISK PORTFOLIO REPORT
Generated: ${date}

PORTFOLIO HEALTH SUMMARY
========================
On-Track Epics: ${this.data.kpis.onTrack}%
At-Risk Epics: ${this.data.kpis.atRisk}%
Blocked Epics: ${this.data.kpis.blocked}%
Resource Utilization: ${this.data.kpis.resourceUtilization}%

EPIC STATUS
===========
${this.data.epics.map(epic => 
    `${epic.id}: ${epic.title} - ${epic.status} (${epic.priority} Priority)`
).join('\n')}

ART PERFORMANCE
===============
${this.data.arts.map(art => 
    `${art.name}: ${art.velocity}/${art.capacity} SP (${art.utilization}% utilization)`
).join('\n')}

KEY METRICS
===========
Delivery Predictability: ${this.data.kpis.deliveryPredictability}%
Quality Score: ${this.data.kpis.qualityScore}/5
Budget Utilization: ${this.data.kpis.budgetUtilization}%

END OF REPORT`;
    }

    generateReport(button) {
        const reportCard = button.closest('.report-card');
        const reportType = reportCard.querySelector('h3').textContent;
        
        console.log('Generating report:', reportType);
        
        // Visual feedback
        const originalText = button.textContent;
        button.textContent = 'Generating...';
        button.disabled = true;
        button.classList.add('loading');
        
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
            button.classList.remove('loading');
            this.showNotification(`${reportType} generated successfully!`, 'success');
        }, 2000);
    }

    showNotification(message, type = 'info') {
        console.log('Showing notification:', message, type);
        
        // Remove any existing notifications
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(n => n.remove());
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        `;
        
        // Add styles for notification
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-base);
            padding: var(--space-16);
            box-shadow: var(--shadow-md);
            z-index: 1000;
            min-width: 300px;
            max-width: 400px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            animation: slideInRight 0.3s ease-out;
        `;
        
        // Set type-specific colors
        const colors = {
            success: 'var(--color-success)',
            error: 'var(--color-error)',
            warning: 'var(--color-warning)',
            info: 'var(--color-info)'
        };
        
        notification.style.borderLeftColor = colors[type] || colors.info;
        notification.style.borderLeftWidth = '4px';
        
        // Style the message
        const messageSpan = notification.querySelector('.notification-message');
        messageSpan.style.cssText = `
            color: var(--color-text);
            font-size: var(--font-size-base);
            line-height: var(--line-height-normal);
            flex: 1;
        `;
        
        // Add close functionality
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.style.cssText = `
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: var(--color-text-secondary);
            padding: 0;
            margin-left: var(--space-12);
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        `;
        
        closeBtn.addEventListener('click', () => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        });
        
        // Add hover effect to close button
        closeBtn.addEventListener('mouseenter', () => {
            closeBtn.style.backgroundColor = 'var(--color-secondary)';
        });
        
        closeBtn.addEventListener('mouseleave', () => {
            closeBtn.style.backgroundColor = 'transparent';
        });
        
        // Add animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        if (!document.querySelector('style[data-notifications]')) {
            style.setAttribute('data-notifications', 'true');
            document.head.appendChild(style);
        }
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(notification)) {
                notification.style.animation = 'slideOutRight 0.3s ease-in';
                setTimeout(() => {
                    if (document.body.contains(notification)) {
                        document.body.removeChild(notification);
                    }
                }, 300);
            }
        }, 5000);
    }

    // Utility methods for data management
    getEpicsByStatus(status) {
        return this.data.epics.filter(epic => 
            epic.status.toLowerCase() === status.toLowerCase()
        );
    }

    getEpicsByPriority(priority) {
        return this.data.epics.filter(epic => 
            epic.priority.toLowerCase() === priority.toLowerCase()
        );
    }

    getEpicsByValueStream(valueStream) {
        return this.data.epics.filter(epic => 
            epic.valueStream === valueStream
        );
    }

    calculatePortfolioMetrics() {
        const totalEpics = this.data.epics.length;
        const completedEpics = this.getEpicsByStatus('Done').length;
        const inProgressEpics = this.getEpicsByStatus('In Progress').length;
        
        return {
            completionRate: (completedEpics / totalEpics) * 100,
            activeWork: inProgressEpics,
            totalBusinessValue: this.data.epics.reduce((sum, epic) => sum + epic.businessValue, 0),
            averageEffort: this.data.epics.reduce((sum, epic) => sum + epic.effort, 0) / totalEpics
        };
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing dashboard...');
    window.dashboard = new AgilePortfolioDashboard();
    
    // Add some demo interactivity
    console.log('🚀 Agile Portfolio Management Dashboard loaded successfully!');
    console.log('📊 Available data:', window.dashboard.data);
    console.log('🎯 Current portfolio metrics:', window.dashboard.calculatePortfolioMetrics());
});

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AgilePortfolioDashboard;
}