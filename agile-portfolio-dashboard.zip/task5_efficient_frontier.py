
# Task 5: Efficient Frontier Construction

# Function to calculate portfolio statistics
def portfolio_stats(weights, returns, cov_matrix, risk_free_rate):
    portfolio_return = np.sum(weights * returns)
    portfolio_variance = np.dot(weights.T, np.dot(cov_matrix, weights))
    portfolio_volatility = np.sqrt(portfolio_variance)
    sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_volatility
    return portfolio_return, portfolio_volatility, sharpe_ratio

# Generate efficient frontier points
target_returns = np.linspace(annual_returns.min(), annual_returns.max(), 50)
efficient_portfolios = []

for target_return in target_returns:
    # Minimize variance for given return
    def minimize_variance(weights):
        return np.dot(weights.T, np.dot(covariance_matrix.values, weights))

    constraints = [
        {'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0},  # Sum weights = 1
        {'type': 'eq', 'fun': lambda x: np.sum(x * annual_returns.values) - target_return}  # Target return
    ]

    bounds = tuple((0, 1) for _ in range(num_assets))

    result = minimize(
        minimize_variance,
        initial_guess,
        method='SLSQP',
        bounds=bounds,
        constraints=constraints
    )

    if result.success:
        ret, vol, sharpe = portfolio_stats(result.x, annual_returns.values, 
                                         covariance_matrix.values, risk_free_rate)
        efficient_portfolios.append({
            'Return': ret,
            'Volatility': vol,
            'Sharpe': sharpe,
            'Weights': result.x
        })

# Convert to DataFrame
efficient_df = pd.DataFrame(efficient_portfolios)

print("Efficient Frontier Generated!")
print(f"Number of efficient portfolios: {len(efficient_df)}")
print("\nSample Efficient Portfolios:")
print(efficient_df.head(10))

# Find portfolio with maximum Sharpe ratio
max_sharpe_idx = efficient_df['Sharpe'].idxmax()
max_sharpe_portfolio = efficient_df.loc[max_sharpe_idx]

print(f"\nMaximum Sharpe Ratio Portfolio:")
print(f"Return: {max_sharpe_portfolio['Return']:.4f} ({max_sharpe_portfolio['Return']*100:.2f}%)")
print(f"Volatility: {max_sharpe_portfolio['Volatility']:.4f} ({max_sharpe_portfolio['Volatility']*100:.2f}%)")
print(f"Sharpe Ratio: {max_sharpe_portfolio['Sharpe']:.4f}")
print("Weights:")
for i, asset in enumerate(annual_returns.index):
    print(f"  {asset}: {max_sharpe_portfolio['Weights'][i]:.4f} ({max_sharpe_portfolio['Weights'][i]*100:.2f}%)")

# Save efficient frontier data
efficient_df_export = efficient_df.drop('Weights', axis=1)
efficient_df_export.to_csv('efficient_frontier_data.csv', index=False)
print("\nEfficient frontier data saved to: efficient_frontier_data.csv")
