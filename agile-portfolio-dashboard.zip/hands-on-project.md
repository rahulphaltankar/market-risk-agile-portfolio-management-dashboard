# Hands-on Project: Portfolio Optimization using Markowitz Model

## Introduction

This hands-on project will guide you through the practical implementation of Harry Markowitz's groundbreaking portfolio optimization theory. You'll work with real financial data to construct optimal investment portfolios that balance risk and return.

The Markowitz model, developed in 1952, revolutionized investment management by introducing mathematical rigor to portfolio construction. Instead of relying on intuition alone, the model provides a systematic approach to diversification and risk management.

## Task 1: Project Overview and Importing Data

### Learning Objectives
- Understand the structure and format of financial data
- Learn to import and examine stock price and return data
- Set up your analytical environment

### Background
Financial data comes in various formats, but we typically work with:
- **Price data**: The actual stock prices over time
- **Return data**: The percentage change in prices (daily, monthly, etc.)

Returns are more useful for portfolio analysis because they:
- Are stationary (suitable for statistical analysis)
- Allow comparison between assets with different price levels
- Capture the relative performance we care about for investment decisions

### Step-by-Step Instructions

#### Method 1: Using Python
```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load the provided sample data
price_data = pd.read_csv('sample_stock_prices.csv', index_col=0, parse_dates=True)
returns_data = pd.read_csv('sample_stock_returns.csv', index_col=0, parse_dates=True)

# Display basic information about the data
print("Price Data Shape:", price_data.shape)
print("Date Range:", price_data.index[0], "to", price_data.index[-1])
print("Assets:", list(price_data.columns))

# Show first few rows
print("\\nFirst 5 rows of Price Data:")
print(price_data.head())
```

#### Method 2: Using Excel
1. Open Excel and import the CSV files
2. Ensure dates are properly formatted
3. Check that all data is numerical (no missing values)
4. Calculate basic statistics using Excel functions

### Key Formulas
- **Daily Return**: \\( R_t = \\frac{P_t - P_{t-1}}{P_{t-1}} = \\frac{P_t}{P_{t-1}} - 1 \\)
- **Log Return**: \\( r_t = \\ln\\left(\\frac{P_t}{P_{t-1}}\\right) \\)

### Questions to Consider
1. What is the difference between price and return data?
2. Why do we use returns instead of prices for portfolio analysis?
3. What does the shape of the data tell us about our sample size?

---

## Task 2: Data Preparation, Calculating Covariance and Correlation

### Learning Objectives
- Calculate and interpret correlation between assets
- Understand covariance and its role in portfolio theory
- Convert daily statistics to annualized figures

### Background
The correlation coefficient measures how two assets move together:
- \\( \\rho = +1 \\): Perfect positive correlation (move together)
- \\( \\rho = 0 \\): No linear relationship
- \\( \\rho = -1 \\): Perfect negative correlation (move opposite)

Covariance measures the same relationship but isn't standardized, making correlation easier to interpret.

### Mathematical Foundation

#### Correlation Formula:
\\[ \\rho_{12} = \\frac{\\text{Cov}(R_1, R_2)}{\\sigma_1 \\sigma_2} \\]

#### Covariance Formula:
\\[ \\text{Cov}(R_1, R_2) = E[(R_1 - \\mu_1)(R_2 - \\mu_2)] \\]

#### Sample Calculation:
\\[ \\text{Cov}(R_1, R_2) = \\frac{1}{n-1} \\sum_{i=1}^{n} (R_{1,i} - \\bar{R_1})(R_{2,i} - \\bar{R_2}) \\]

### Step-by-Step Instructions

#### Python Implementation:
```python
# Calculate annualized expected returns
annual_returns = returns_data.mean() * 252  # 252 trading days per year

# Calculate annualized volatilities  
annual_volatility = returns_data.std() * np.sqrt(252)

# Calculate correlation matrix
correlation_matrix = returns_data.corr()

# Calculate covariance matrix (annualized)
covariance_matrix = returns_data.cov() * 252

print("Correlation between assets:", correlation_matrix.iloc[0,1])
print("Covariance between assets:", covariance_matrix.iloc[0,1])
```

#### Excel Implementation:
- Use `CORREL(array1, array2)` function
- Use `COVARIANCE.S(array1, array2)` function
- Multiply daily covariance by 252 for annual figure

### Interpretation Guidelines
- **High positive correlation (0.7-1.0)**: Assets move together; limited diversification benefit
- **Low correlation (0.0-0.3)**: Some diversification benefit
- **Negative correlation (-1.0-0.0)**: Strong diversification benefit; assets offset each other

### Practice Exercise
Calculate the correlation and covariance for your sample data and interpret the results. What does this suggest about the diversification potential?

---

## Task 3: Calculating Portfolio Variance and Sharpe Ratio

### Learning Objectives
- Apply the Markowitz portfolio variance formula
- Calculate and interpret the Sharpe ratio
- Understand risk-adjusted performance measurement

### Background
The Sharpe ratio, developed by William Sharpe, measures risk-adjusted returns. It answers the question: "How much extra return do I receive for the extra volatility of holding this portfolio instead of a risk-free asset?"

### Mathematical Foundation

#### Portfolio Return:
\\[ E(R_p) = w_1 E(R_1) + w_2 E(R_2) \\]

#### Portfolio Variance (Markowitz Formula):
\\[ \\sigma_p^2 = w_1^2\\sigma_1^2 + w_2^2\\sigma_2^2 + 2w_1w_2\\sigma_1\\sigma_2\\rho_{12} \\]

#### Portfolio Standard Deviation:
\\[ \\sigma_p = \\sqrt{\\sigma_p^2} \\]

#### Sharpe Ratio:
\\[ SR = \\frac{E(R_p) - R_f}{\\sigma_p} \\]

Where:
- \\( w_i \\) = weight of asset i
- \\( \\sigma_i \\) = standard deviation of asset i  
- \\( \\rho_{12} \\) = correlation between assets 1 and 2
- \\( R_f \\) = risk-free rate

### Step-by-Step Calculation

#### Example: 60% Asset 1, 40% Asset 2
```python
# Define portfolio weights
w1, w2 = 0.6, 0.4

# Calculate portfolio return
portfolio_return = w1 * annual_returns.iloc[0] + w2 * annual_returns.iloc[1]

# Calculate portfolio variance
sigma1 = annual_volatility.iloc[0]
sigma2 = annual_volatility.iloc[1]
rho12 = correlation_matrix.iloc[0,1]

portfolio_variance = (w1**2 * sigma1**2 + 
                     w2**2 * sigma2**2 + 
                     2*w1*w2*sigma1*sigma2*rho12)

# Calculate portfolio volatility
portfolio_volatility = np.sqrt(portfolio_variance)

# Calculate Sharpe ratio
risk_free_rate = 0.03  # 3% annually
sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_volatility
```

### Sharpe Ratio Interpretation
- **< 1.0**: Below average performance
- **1.0 - 1.99**: Good performance  
- **2.0 - 2.99**: Very good performance
- **> 3.0**: Excellent performance

### Diversification Benefits
The portfolio variance formula shows that when correlation < 1, the portfolio risk is less than the weighted average of individual asset risks. This is the mathematical basis of diversification.

### Practice Exercises
1. Calculate portfolio statistics for different weight combinations
2. Observe how correlation affects portfolio risk
3. Find the portfolio with the highest Sharpe ratio through trial and error

---

## Task 4: Markowitz Model Optimization

### Learning Objectives
- Implement mathematical optimization to find optimal portfolio weights
- Understand constrained optimization in portfolio context
- Compare optimal vs. naive diversification strategies

### Background
The Markowitz model finds the portfolio that maximizes the Sharpe ratio (or minimizes risk for a given return) through mathematical optimization. This eliminates guesswork and provides the theoretically optimal solution.

### Optimization Problem
We want to:
\\[ \\max_{w_1, w_2} \\frac{E(R_p) - R_f}{\\sigma_p} \\]

Subject to:
- \\( w_1 + w_2 = 1 \\) (weights sum to 100%)
- \\( w_1, w_2 \\geq 0 \\) (no short selling)

### Implementation Steps

#### Python with SciPy:
```python
from scipy.optimize import minimize

def negative_sharpe_ratio(weights, returns, cov_matrix, risk_free_rate):
    \"\"\"Calculate negative Sharpe ratio (we minimize the negative to maximize)\"\"\"
    portfolio_return = np.sum(weights * returns)
    portfolio_variance = np.dot(weights.T, np.dot(cov_matrix, weights))
    portfolio_volatility = np.sqrt(portfolio_variance)
    sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_volatility
    return -sharpe_ratio

# Set up optimization
num_assets = 2
initial_guess = np.array([0.5, 0.5])  # Equal weights to start
bounds = tuple((0, 1) for _ in range(num_assets))  # Between 0 and 1
constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0})

# Solve
result = minimize(
    negative_sharpe_ratio,
    initial_guess,
    args=(annual_returns.values, covariance_matrix.values, risk_free_rate),
    method='SLSQP',
    bounds=bounds,
    constraints=constraints
)

optimal_weights = result.x
```

#### Excel Solver:
1. Set up your Sharpe ratio calculation
2. Use Excel Solver add-in to maximize Sharpe ratio
3. Set constraints: weights sum to 1, all weights ≥ 0

### Key Insights
- The optimal portfolio typically differs from equal weighting
- Lower correlation between assets allows for better optimization
- The optimization process considers both return and risk simultaneously

### Comparison Analysis
Compare your optimal portfolio to:
1. Equal-weight portfolio (50%-50%)
2. Individual assets (100%-0% and 0%-100%)
3. Other arbitrary weight combinations

---

## Task 5: Efficient Frontier Construction and Analysis

### Learning Objectives
- Construct and visualize the efficient frontier
- Understand the concept of Pareto optimality in portfolio selection
- Identify the capital allocation line and market portfolio

### Background
The efficient frontier represents all portfolios that offer the highest expected return for each level of risk. It's the "north-west" boundary of all possible portfolios - no portfolio exists that offers both higher return and lower risk than points on the frontier.

### Mathematical Approach
For each target return level \\( \\bar{R} \\), solve:
\\[ \\min_{w_1, w_2} \\sigma_p^2 = w_1^2\\sigma_1^2 + w_2^2\\sigma_2^2 + 2w_1w_2\\sigma_1\\sigma_2\\rho_{12} \\]

Subject to:
- \\( w_1 E(R_1) + w_2 E(R_2) = \\bar{R} \\) (achieve target return)
- \\( w_1 + w_2 = 1 \\) (fully invested)

### Implementation
```python
# Generate target returns from minimum to maximum asset return
target_returns = np.linspace(annual_returns.min(), annual_returns.max(), 50)
efficient_portfolios = []

for target_return in target_returns:
    # Minimize variance subject to achieving target return
    def minimize_variance(weights):
        return np.dot(weights.T, np.dot(covariance_matrix.values, weights))
    
    constraints = [
        {'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0},
        {'type': 'eq', 'fun': lambda x: np.sum(x * annual_returns.values) - target_return}
    ]
    
    result = minimize(minimize_variance, [0.5, 0.5], 
                     method='SLSQP', constraints=constraints,
                     bounds=[(0, 1), (0, 1)])
    
    if result.success:
        ret, vol, sharpe = portfolio_stats(result.x, annual_returns.values, 
                                         covariance_matrix.values, risk_free_rate)
        efficient_portfolios.append([ret, vol, sharpe])
```

### Key Concepts
- **Global Minimum Variance Portfolio**: The leftmost point on the frontier
- **Maximum Sharpe Ratio Portfolio**: The portfolio with the steepest slope from the risk-free rate
- **Capital Allocation Line**: The line from risk-free rate through the optimal portfolio

### Practical Applications
1. **Risk Budgeting**: Choose portfolio based on risk tolerance
2. **Performance Evaluation**: Compare actual portfolios to efficient frontier
3. **Asset Allocation**: Determine strategic portfolio weights

### Limitations and Assumptions
The Markowitz model assumes:
- Returns are normally distributed
- Investors are risk-averse and rational
- No transaction costs or taxes
- Can borrow/lend at risk-free rate
- Single-period investment horizon
- Known expected returns, volatilities, and correlations

### Real-World Considerations
- **Estimation Error**: Historical data may not predict future relationships
- **Transaction Costs**: Frequent rebalancing can be expensive
- **Liquidity Constraints**: Some assets may be difficult to trade
- **Behavioral Factors**: Investors may not behave rationally

## Summary

Through these five tasks, you've learned to:
1. Work with financial data and calculate returns
2. Measure relationships between assets using correlation and covariance
3. Construct portfolios and evaluate them using the Sharpe ratio
4. Find mathematically optimal portfolio weights
5. Visualize the risk-return trade-off through the efficient frontier

This foundation in portfolio optimization will serve you well in advanced finance courses and professional investment management roles.