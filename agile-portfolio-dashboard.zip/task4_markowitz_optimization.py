
# Task 4: Markowitz Model Portfolio Optimization

from scipy.optimize import minimize

# Define the objective function (negative Sharpe ratio to minimize)
def negative_sharpe_ratio(weights, returns, cov_matrix, risk_free_rate):
    portfolio_return = np.sum(weights * returns)
    portfolio_variance = np.dot(weights.T, np.dot(cov_matrix, weights))
    portfolio_volatility = np.sqrt(portfolio_variance)
    sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_volatility
    return -sharpe_ratio  # Negative because we want to maximize

# Define constraints
def constraint_sum_weights(weights):
    return np.sum(weights) - 1.0  # Sum of weights must equal 1

# Set up the optimization problem
num_assets = len(annual_returns)
initial_guess = np.array([1/num_assets] * num_assets)  # Equal weights initially
bounds = tuple((0, 1) for _ in range(num_assets))  # Weights between 0 and 1
constraints = ({'type': 'eq', 'fun': constraint_sum_weights})

print("Starting Markowitz Optimization...")
print(f"Initial guess: {initial_guess}")

# Solve optimization
result = minimize(
    negative_sharpe_ratio,
    initial_guess,
    args=(annual_returns.values, covariance_matrix.values, risk_free_rate),
    method='SLSQP',
    bounds=bounds,
    constraints=constraints
)

optimal_weights = result.x
optimal_return = np.sum(optimal_weights * annual_returns)
optimal_variance = np.dot(optimal_weights.T, np.dot(covariance_matrix.values, optimal_weights))
optimal_volatility = np.sqrt(optimal_variance)
optimal_sharpe = (optimal_return - risk_free_rate) / optimal_volatility

print("\nOptimization Results:")
print(f"Success: {result.success}")
print(f"\nOptimal Portfolio Weights:")
for i, asset in enumerate(annual_returns.index):
    print(f"{asset}: {optimal_weights[i]:.4f} ({optimal_weights[i]*100:.2f}%)")

print(f"\nOptimal Portfolio Performance:")
print(f"Expected Return: {optimal_return:.4f} ({optimal_return*100:.2f}%)")
print(f"Volatility: {optimal_volatility:.4f} ({optimal_volatility*100:.2f}%)")
print(f"Sharpe Ratio: {optimal_sharpe:.4f}")

# Compare with equal-weight portfolio
equal_weights = np.array([0.5, 0.5])
equal_return = np.sum(equal_weights * annual_returns)
equal_variance = np.dot(equal_weights.T, np.dot(covariance_matrix.values, equal_weights))
equal_volatility = np.sqrt(equal_variance)
equal_sharpe = (equal_return - risk_free_rate) / equal_volatility

print(f"\nComparison with Equal-Weight Portfolio (50%-50%):")
print(f"Equal-weight Sharpe Ratio: {equal_sharpe:.4f}")
print(f"Optimal Sharpe Ratio: {optimal_sharpe:.4f}")
print(f"Improvement: {((optimal_sharpe - equal_sharpe) / equal_sharpe * 100):.2f}%")
