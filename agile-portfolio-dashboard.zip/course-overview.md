# Portfolio Optimization using Markowitz Model

## Welcome!

Welcome to Portfolio Optimization using Markowitz Model. This is a project-based course which should take approximately 2 hours to finish. This course will provide you with hands-on experience in modern portfolio theory and practical skills in constructing optimal investment portfolios.

## Course Objectives

In this course, we are going to focus on four learning objectives:

1. **Be able to calculate covariance and correlation of two assets**
   - Understand the mathematical relationship between asset returns
   - Learn to quantify how assets move together or independently
   - Apply statistical measures to real financial data

2. **Calculate variance and Sharpe ratio for two-asset portfolio**
   - Master portfolio variance calculation using the Markowitz formula
   - Understand risk-adjusted returns through the Sharpe ratio
   - Learn to evaluate portfolio performance relative to risk-free investments

3. **Use Markowitz model to optimize for the highest Sharpe ratio in two-asset portfolio**
   - Apply mathematical optimization techniques to portfolio construction
   - Find the optimal weight allocation between assets
   - Understand the trade-offs between risk and return

4. **Understand what the efficient frontier is and how it is applied in portfolio management**
   - Visualize the risk-return relationship across different portfolios
   - Identify efficient vs. inefficient portfolio combinations
   - Learn practical applications in investment decision-making

By the end of this course, you will be able to build a two-asset Markowitz model and apply it to real-world investment scenarios.

## Course Structure

This course is divided into 4 parts:

1. **Course Overview**: This introductory reading material
2. **Portfolio Optimization using Markowitz Model**: The hands-on project that we will work on
3. **Discussion Prompt**: Preferred way for portfolio allocation
4. **Graded Quiz**: The final assignment that you need to pass to finish the course successfully

## Project Structure

The hands-on project on Portfolio Optimization using Markowitz Model is divided into the following tasks:

- **Task 1**: Project Overview and importing the data
- **Task 2**: Preparing data, calculating covariance and correlation
- **Task 3**: Calculating Sharpe ratio for two-asset portfolio
- **Task 4**: Using Markowitz model to optimize for the highest Sharpe ratio
- **Task 5**: Understanding and constructing the efficient frontier

## Prerequisites

- Basic understanding of statistics and probability
- Familiarity with spreadsheet software (Excel) or Python programming
- Elementary knowledge of financial markets and investments
- Access to Python environment (optional but recommended)

## Required Tools and Data

- Python (with pandas, numpy, scipy, matplotlib libraries) OR Excel
- Sample financial data provided in the course materials
- Portfolio optimization templates and calculation guides

## Learning Outcomes

Upon successful completion of this course, you will:

- Have practical experience with portfolio optimization techniques
- Understand the mathematical foundations of modern portfolio theory
- Be able to implement Markowitz optimization in real-world scenarios
- Know how to evaluate and compare different investment portfolios
- Understand the limitations and assumptions of the Markowitz model

## Assessment

Your learning will be assessed through:
- Completion of hands-on tasks (60%)
- Participation in discussion forum (20%)
- Final graded quiz (20%)

## Getting Started

To begin the course:
1. Review the theoretical background materials
2. Download the provided data files and templates
3. Set up your computational environment (Python or Excel)
4. Begin with Task 1 of the hands-on project

We're excited to have you join us on this journey into portfolio optimization!